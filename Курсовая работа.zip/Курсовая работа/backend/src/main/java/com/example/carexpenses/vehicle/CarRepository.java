package com.example.carexpenses.vehicle;

import com.example.carexpenses.user.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CarRepository extends JpaRepository<Car, Long> {
    List<Car> findByOwner(User owner);
}

