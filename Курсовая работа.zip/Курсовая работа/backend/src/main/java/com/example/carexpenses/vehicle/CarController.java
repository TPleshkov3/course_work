package com.example.carexpenses.vehicle;

import com.example.carexpenses.user.User;
import com.example.carexpenses.user.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cars")
@CrossOrigin(origins = "*")
public class CarController {

    private final CarRepository carRepository;
    private final UserRepository userRepository;

    public CarController(CarRepository carRepository, UserRepository userRepository) {
        this.carRepository = carRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public List<Car> getMyCars(@AuthenticationPrincipal UserDetails userDetails) {
        User owner = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();
        return carRepository.findByOwner(owner);
    }

    @PostMapping
    public Car createCar(@AuthenticationPrincipal UserDetails userDetails,
                         @Valid @RequestBody Car car) {
        User owner = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();
        car.setOwner(owner);
        return carRepository.save(car);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCar(@PathVariable Long id,
                                       @AuthenticationPrincipal UserDetails userDetails) {
        User owner = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();
        Car car = carRepository.findById(id).orElseThrow();
        if (!car.getOwner().getId().equals(owner.getId())) {
            return ResponseEntity.status(403).build();
        }
        carRepository.delete(car);
        return ResponseEntity.noContent().build();
    }
}

