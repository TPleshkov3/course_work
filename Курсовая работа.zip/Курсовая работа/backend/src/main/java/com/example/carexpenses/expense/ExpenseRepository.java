package com.example.carexpenses.expense;

import com.example.carexpenses.vehicle.Car;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    List<Expense> findByCar(Car car);
    List<Expense> findByCarAndDateBetween(Car car, LocalDate from, LocalDate to);
}

