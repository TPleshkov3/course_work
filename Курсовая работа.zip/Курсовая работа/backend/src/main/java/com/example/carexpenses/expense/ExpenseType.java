package com.example.carexpenses.expense;

public enum ExpenseType {
    FUEL,
    OIL,
    MAINTENANCE,
    REPAIR,
    INSURANCE,
    TAX,
    FINE,
    OTHER
}

