package com.example.carexpenses.expense;

import com.example.carexpenses.user.User;
import com.example.carexpenses.user.UserRepository;
import com.example.carexpenses.vehicle.Car;
import com.example.carexpenses.vehicle.CarRepository;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Year;
import java.util.List;

record ExpenseReportItem(int month, BigDecimal totalAmount) {}

@RestController
@RequestMapping("/api/expenses")
@CrossOrigin(origins = "*")
public class ExpenseController {

    private final ExpenseRepository expenseRepository;
    private final CarRepository carRepository;
    private final UserRepository userRepository;

    public ExpenseController(ExpenseRepository expenseRepository,
                             CarRepository carRepository,
                             UserRepository userRepository) {
        this.expenseRepository = expenseRepository;
        this.carRepository = carRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/car/{carId}")
    public ResponseEntity<List<Expense>> getExpenses(@PathVariable Long carId,
                                                     @AuthenticationPrincipal UserDetails userDetails) {
        Car car = getUserCar(carId, userDetails);
        return ResponseEntity.ok(expenseRepository.findByCar(car));
    }

    @PostMapping("/car/{carId}")
    public ResponseEntity<Expense> addExpense(@PathVariable Long carId,
                                              @AuthenticationPrincipal UserDetails userDetails,
                                              @Valid @RequestBody Expense expense) {
        Car car = getUserCar(carId, userDetails);
        expense.setCar(car);
        return ResponseEntity.ok(expenseRepository.save(expense));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteExpense(@PathVariable Long id,
                                           @AuthenticationPrincipal UserDetails userDetails) {
        Expense expense = expenseRepository.findById(id).orElseThrow();
        Car car = expense.getCar();
        User owner = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();
        if (!car.getOwner().getId().equals(owner.getId())) {
            return ResponseEntity.status(403).build();
        }
        expenseRepository.delete(expense);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/report/{carId}/{year}")
    public ResponseEntity<List<ExpenseReportItem>> getYearReport(@PathVariable Long carId,
                                                                 @PathVariable int year,
                                                                 @AuthenticationPrincipal UserDetails userDetails) {
        Car car = getUserCar(carId, userDetails);
        LocalDate from = Year.of(year).atMonth(1).atDay(1);
        LocalDate to = Year.of(year).atMonth(12).atEndOfMonth();

        List<Expense> expenses = expenseRepository.findByCarAndDateBetween(car, from, to);

        List<ExpenseReportItem> report = expenses.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                        e -> e.getDate().getMonthValue(),
                        java.util.stream.Collectors.mapping(
                                Expense::getAmount,
                                java.util.stream.Collectors.reducing(BigDecimal.ZERO, BigDecimal::add)
                        )
                ))
                .entrySet()
                .stream()
                .map(e -> new ExpenseReportItem(e.getKey(), e.getValue()))
                .sorted(java.util.Comparator.comparingInt(ExpenseReportItem::month))
                .toList();

        return ResponseEntity.ok(report);
    }

    @GetMapping("/range/{carId}")
    public ResponseEntity<List<Expense>> getExpensesInRange(@PathVariable Long carId,
                                                            @AuthenticationPrincipal UserDetails userDetails,
                                                            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                                                            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        Car car = getUserCar(carId, userDetails);
        return ResponseEntity.ok(expenseRepository.findByCarAndDateBetween(car, from, to));
    }

    private Car getUserCar(Long carId, UserDetails userDetails) {
        User owner = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();
        Car car = carRepository.findById(carId).orElseThrow();
        if (!car.getOwner().getId().equals(owner.getId())) {
            throw new RuntimeException("Forbidden");
        }
        return car;
    }
}

